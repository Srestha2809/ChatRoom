const schema = `
type Query {
 project1_setup: results
 },
type results{
 results: String   
} 
`;
export { schema };