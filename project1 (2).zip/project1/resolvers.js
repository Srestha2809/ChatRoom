import * as dbRtns from "./db_routines.js";
import * as cfg from "./config.js";
import * as setup from "./project1_setup.js"
const resolvers = {
    Query: {
        async project1_setup() {
            try {
                const result = await setup.getCounts();
                return result;
            }
            catch (error) {
                throw new Error(error);
            }
        }
    }
};
export { resolvers };