import * as cfg from "./config.js";
import * as utils from "./utilites.js";
import * as dbRtns from "./db_routines.js";

const getCounts = async () => {
    try {
        // let results = "";

        // results += `Retrieved Country JSON from remote web site. \n`;


        // results += `There are ${Object.keys(alertJson.data).length} alerts and ${countryJson.length} countries`;
        // console.log(results);

        const db = await dbRtns.getDBInstance();
        let countryJson = await dbRtns.getJSONFromWWWPromise(cfg.countryJson);
        let alertJson = await dbRtns.getJSONFromWWWPromise(cfg.alertJson);
        console.log("Retrieved Alert JSON from remote web site.");
        console.log("Retrieved Country JSON from remote web site.")
        let results = await dbRtns.deleteAll(db, cfg.collect);
        console.log(
            `deleted ${results.deletedCount} documents from countries collection`
        );

        let callAlert = countryJson.map((result) => {
            if (result["alpha-2"] === alertJson.data[result["alpha-2"]]) {
                ({
                    country: result["alpha-2"], name: result.name,
                    text: alertJson.data[result["alpha-2"]].eng["advisory-text"],
                    date: alertJson.data[result["alpha-2"]]["date-published"].date,
                    region: result.region, subregion: result["sub-region"]
                })
            }
            else {
                ({
                    country: result["alpha-2"], name: result.name,
                    text: "No travel alerts",
                    date: "",
                    region: result.region, subregion: result["sub-region"]
                })
            }
        })

        results = await dbRtns.addMany(db, cfg.collect, callAlert);
        console.log(
            `added ${results.insertedCount} documents to the alerts collection`
        );

    }
    catch (error) {
        console.log(error.message);
    }
};

getCounts();